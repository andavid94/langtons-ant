/*
 ** Author: David An
 ** Date: Jan 15 2018
 ** Description: inputValidation.hpp serves as the function prototype for
 ** 			 inputValidation.cpp
 */

#ifndef inputValidation_hpp
#define inputValidation_hpp

#include <iostream>

int inputValidation(int, int);

#endif

