/*
 ** Author: David An
 ** Date: Jan 15 2018
 ** Description: menu.hpp declares the menu functions
 */

#ifndef menu_hpp
#define menu_hpp
#include <string>
#include <iostream>

int beginGame();
int reprompt();

#endif

